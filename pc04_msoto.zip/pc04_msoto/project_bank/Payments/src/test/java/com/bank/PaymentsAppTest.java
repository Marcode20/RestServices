package com.bank;

import com.bank.model.Payment;
import com.bank.service.PayAndSendService;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PaymentsAppTest {

    @Autowired
    PayAndSendService payAndSendService;

    @Test
    public void savePaymentAndSendMessage(){
        Payment payment = new Payment();
        payment.setDni("123456789");
        payment.setAmount(1000.00);

        payAndSendService.savePaymentAndSendMessage(payment);
    }


}
