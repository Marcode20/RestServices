package com.bank.service;

import com.bank.model.Client;
import com.bank.model.Payment;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PayAndSendService {
    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ClientService clientService;

    @Autowired
    private JmsTemplate jmsTemplate;

    @Value("${app.queue}")
    private String queueName;

    public void savePaymentAndSendMessage(Payment payment){

        paymentService.save(payment);

        try {
            ObjectMapper om = new ObjectMapper();

            om.registerModule(new JavaTimeModule());
            om.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

            String paymentString = om.writeValueAsString(payment);
            jmsTemplate.convertAndSend(queueName, paymentString);

            log.info("Message sent !");

        } catch (JsonProcessingException e) {
            e.printStackTrace();
            log.error("Error sending message!");
        }

    }
}
