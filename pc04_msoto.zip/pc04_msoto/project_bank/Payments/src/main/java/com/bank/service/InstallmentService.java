package com.bank.service;

import com.bank.model.Installment;
import com.bank.repository.InstallmentRepository;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InstallmentService implements BaseService<Installment, Long> {

    @Autowired
    InstallmentRepository installmentRepository;

    @Override
    public void save(Installment installment) {
        installmentRepository.save(installment);
    }

    @Override
    public void update(Installment installment) {
        installmentRepository.save(installment);
    }

    @Override
    public void delete(Installment installment) {
        installmentRepository.save(installment);
    }

    @Override
    public List<Installment> findAll() {
        return installmentRepository.findAll();
    }

    @Override
    public Installment findById(Long id) {
        return installmentRepository.findById(id).orElseGet(null);
    }
}
