package com.bank.resource;

import com.bank.model.Installment;
import com.bank.model.Loan;
import com.bank.service.InstallmentService;
import com.bank.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class LoanResource {
    @Autowired
    LoanService loanService;

    @Autowired
    InstallmentService installmentService;

    @GetMapping("/loans")
    public ResponseEntity findAll(){
        List<Loan> loans = loanService.findAll();
        if(loans == null){
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity(loans, HttpStatus.OK);
    }

    @PostMapping("/loans")
    public ResponseEntity create(@RequestBody Loan loan){
        List<Installment> installmentsList = new ArrayList<Installment>();

        for (int i = 0; i <loan.getNumberOfFees(); i++){
            Installment installment = new Installment();
            installment.setFeeAmount(loan.getTotalAmount() / loan.getNumberOfFees());
            installment.setLoan(loan);
            installmentsList.add(installment);
            installmentService.save(installment);
        }
        loan.setInstallments(installmentsList);
        loanService.save(loan);

        return new ResponseEntity(loan, HttpStatus.CREATED);
    }
}
