package com.bank.service;

import com.bank.model.Loan;
import com.bank.repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LoanService implements BaseService<Loan, Long> {

    @Autowired
    LoanRepository loanRepository;

    @Override
    public void save(Loan loan) {
        loanRepository.save(loan);
    }

    @Override
    public void update(Loan loan) {
        loanRepository.save(loan);
    }

    @Override
    public void delete(Loan loan) {
        loanRepository.delete(loan);
    }

    @Override
    public List<Loan> findAll() {
        return loanRepository.findAll();
    }

    @Override
    public Loan findById(Long id) {
        return loanRepository.findById(id).orElseGet(null);
    }
}
