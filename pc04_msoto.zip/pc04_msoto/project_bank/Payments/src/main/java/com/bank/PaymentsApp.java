package com.bank;

import com.bank.model.Payment;
import com.bank.service.PayAndSendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentsApp {
    @Autowired
    PayAndSendService payAndSendService;

    public static void main(String[] args){
        SpringApplication.run(PayAndSendService.class, args);
    }

}
